# Argus

## Code Examples

```sh
poetry run kedro viz --load-file=notebooks/kedro_viz_config.json
```

## Example Pipeline Visualisation

![Example Pipeline](notebooks/kedro-pipeline.png)
